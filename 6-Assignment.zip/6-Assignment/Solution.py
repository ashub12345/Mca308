import pandas as pd
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn.decomposition import PCA

iris = load_iris()
X = iris.data
y = iris.target
target_names = iris.target_names

# apply PCA (2 components)
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X)

df = pd.DataFrame(X_pca, columns=['PC1','PC2'])
df['target'] = y


plt.figure(figsize=(8,6))
for i, target_name in enumerate(target_names):
    plt.scatter(df[df['target']==i]['PC1'],
                df[df['target']==i]['PC2'],
                label=target_name)

plt.xlabel("Principal Component 1")
plt.ylabel("Principal Component 2")
plt.title("PCA on Iris Dataset (2 Components)")
plt.legend()
plt.show()
