import pandas as pd

df = pd.read_csv("archive/AWCustomers.csv")

# (a)
features = ["BirthDate","Education","Occupation","Gender","MaritalStatus",
            "HomeOwnerFlag","NumberCarsOwned","TotalChildren","YearlyIncome","CountryRegionName"]

# (b)
new_df = df[features].copy()
new_df["BirthDate"] = pd.to_datetime(new_df["BirthDate"], errors="coerce")
new_df["Age"] = 2025 - new_df["BirthDate"].dt.year
new_df = new_df.drop(columns=["BirthDate"])

# (c)
dtype_map = {
    "Age":"Continuous-Ratio",
    "Education":"Categorical-Ordinal",
    "Occupation":"Categorical-Nominal",
    "Gender":"Categorical-Nominal",
    "MaritalStatus":"Categorical-Nominal",
    "HomeOwnerFlag":"Discrete-Nominal",
    "NumberCarsOwned":"Discrete-Ratio",
    "TotalChildren":"Discrete-Ratio",
    "YearlyIncome":"Continuous-Ratio",
    "CountryRegionName":"Categorical-Nominal"
}

print(new_df.head())
print(pd.DataFrame(list(dtype_map.items()), columns=["Attribute","DataType"]))
